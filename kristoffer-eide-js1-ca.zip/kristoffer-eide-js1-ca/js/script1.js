const result = document.querySelector(".results");
const url = "https://cat-fact.herokuapp.com/facts/random?animal_type=cat&amount=3";

async function fetchFacts() {
	try {
		const response = await fetch(url);
		const json = await response.json();
		const results = json.results;

		results.innerHTML = "";

		for (let i = 0; i < results.length; i++) {
			if (i === 3) {
				break;
			}

			results.innerHTML += `<div>
									<p>${[ i ].text}</p>
									<p>${[ i ].type}</p>
									<p>${[ i ].user}</p>
									</div>`;
		}
	} catch (error) {
		console.log(error);
		results.innerHTML = "Sorry, we are temporarily out of Cat facts.";
	}
}

fetchFacts();
