const details = document.querySelector(".details");

const queryString = document.location.search;
const params = new URLSearchParams(queryString);

async function fetchFacts() {
	try {
		const url = "https://cat-fact.herokuapp.com/facts/591f98803b90f7150a19c229";
		const apiResponse = await fetch(url);
		const apiResponseResult = await apiResponse.json();

		console.log(apiResponseResult);
	} catch (error) {
		console.log(error);
		details.innerHTML = "Sorry, we are temporarily out of Cat facts.";
	}
}

fetchFacts();
