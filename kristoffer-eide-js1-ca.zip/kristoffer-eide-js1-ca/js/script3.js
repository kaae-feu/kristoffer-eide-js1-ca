const name = document.getElementById("name");
const subject = document.getElementById("subject");
const address = document.getElementById("address");
const email = document.getElementById("email");
const form = document.getElementById("form");
const errorElement = document.getElementById("error");

form.addEventListener("submit", (e) => {
	let messages = [];
	if (subject.value.length <= 10) {
		messages.push("Subject must have a minimum length of 10 characters");
	}

	if (address.value.length <= 10) {
		messages.push("Address must have a minimum length of 25 characters");
	}

	if (messages.length > 0) {
		e.preventDefault();
		errorElement.innerText = messages.join(", ");
	}
});
